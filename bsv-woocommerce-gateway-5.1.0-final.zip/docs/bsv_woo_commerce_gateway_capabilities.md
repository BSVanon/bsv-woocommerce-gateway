# BSV WooCommerce Gateway Capabilities (minimal sketch)

## Scope
- One payment method: **Bitcoin SV (BSV)** only.
- Goal: accept BSV payments **directly to the merchant** (self-custody).

## Merchant configuration
- Preferred: merchant provides an **extended public key (xpub/MPK, BIP32)** so the plugin can derive a fresh receive address per order (no private keys stored on the site).
- Wallet note: **ElectrumSV** is one option for exporting an MPK/xpub, but **any BIP32-capable wallet** that can provide the correct xpub/derivation path is acceptable.
- Fallback: merchant provides a **static BSV receive address** (simpler, but address reuse).
- Optional advanced: support an **address pool** (pre-generated receive addresses) that can be replenished by the merchant.
- Basic settings: gateway enable/disable, display name, instructions.

## Checkout / customer UX
- On checkout / thank-you page: show **BSV amount + destination address + QR code**.
- Optional: **“Pay with Yours Wallet”** button (if the customer has the Yours extension) that triggers a wallet prompt to send the exact amount.
- Clear payment status messaging (awaiting payment / paid / expired).

## Pricing / FX
- Convert store currency → BSV via an **exchange-rate feed**.
- Include a configurable **multiplier** to pad for volatility/fees.
- Optional: configurable **exchange-rate cache time** (seconds/minutes).
- Persist the **exact rate used** into **order metadata** for audit/reconciliation.

## Legacy behaviors worth emulating (from mboyd changelog)
- Admin setting: **selectable gateway icon** (with guidance for adding new icons).
- Address management: **reuse expired addresses** option.
- Scheduling: support **WP-Cron** and “real cron” style scheduling (behavior when `DISABLE_WP_CRON` is set).
- Notifications hardening: **secret_key validation** (anti-spoofing) for any payment-notification endpoint.
- QR conveniences: include a **QR image in the checkout pay screen and order emails**.

## Address / invoice generation
- Generate a unique payment destination per order (HD derivation from MPK).
- Define payment window (e.g., pay within X minutes).

## Payment detection
- Detect inbound payments to the derived address.
- Handle: exact pay, underpay, overpay.
- Define “paid” rule: 0-conf vs 1-conf (configurable).

## Order state updates
- Map payment events to Woo order states (e.g., pending → on-hold → processing/completed).
- Optional setting: **auto-complete** paid orders (especially for virtual/downloadable items).

## Admin ops
- Admin view: show derived address, expected amount, received amount, txid(s), timestamps.
- Logging for rate lookups + payment checks.

## Next steps: spin up the legacy mboyd plugin (to see it work)
1. **Create an isolated local test site** (Docker or a throwaway VM). Do not expose it publicly.
2. Install **WordPress 5.0.2** (the plugin says it was “tested up to” this version).
3. Install a WooCommerce version that supports WP 5.0 (historically **3.5.1+** was recommended for WP 5.0 compatibility).
4. Install the plugin by copying the repo folder to: `wp-content/plugins/bitcoin-sv-payments-for-woocommerce/` and activating it.
5. Configure the gateway with a **BIP32 xpub/MPK** from a wallet (ElectrumSV is one option).
6. Create a simple product, run checkout, and confirm you see the **pay page** with address + amount + QR.
7. Send a small BSV payment to the derived address.
8. Trigger payment detection:
   - If using WP-Cron: visit the site a few times.
   - If using real cron: add a cron entry that hits WP-Cron (or the plugin’s cron hook, depending on how it’s wired).
9. Observe the order status transition + order metadata (address, rate used, txid if available).

## Non-goals (for this sketch)
- BCH or any multi-coin gateway support.
- Custodial processing / third-party invoice processor.
- Refund automation, subscriptions, complex partial-shipment workflows.
 (for this sketch)
- BCH or any multi-coin gateway support.
- Custodial processing / third-party invoice processor.
- Refund automation, subscriptions, complex partial-shipment workflows.

