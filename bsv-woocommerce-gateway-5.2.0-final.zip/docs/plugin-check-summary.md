# Plugin Check Chunking & Remediation Log

## 1. Chunked Scan Strategy
- Full `wp plugin check` run (UI/CLI) repeatedly timed out, so we broke the "Plugin Repo" category into **small CLI batches**.
- Each batch is scoped to the plugin directory via `wp plugin check wp-content/plugins/bitcoin-sv-payments-for-woocommerce --checks=...` so WordPress core noise is excluded.
- Results from every batch are stored as JSON for reproducibility.

### Batches Completed
| Batch | Checks | Output |
|-------|--------|--------|
| 1 | `plugin_header_fields`, `plugin_content`, `plugin_review_phpcs` | `docs/plugin-check-batch1.json` |
| 2 | `prefixing`, `code_obfuscation`, `plugin_updater`, `plugin_uninstall` | `docs/plugin-check-batch2.json` |
| 3 | `minified_files`, `direct_file_access`, `setting_sanitization`, `trademarks`, `localhost`, `no_unfiltered_uploads`, `offloading_files` | `docs/plugin-check-batch3.json` |
| 4 | `direct_db_queries`, `direct_db` | `docs/plugin-check-batch4.json` |
| 5 | `late_escaping`, `safe_redirect`, `setting_sanitization` | `docs/plugin-check-batch5.json` |
| 6 | `i18n_usage` | `docs/plugin-check-batch6.json` |

## 2. Aggregated Issue Lists
- Each JSON file contains only our plugin paths, so the collection of `docs/plugin-check-batch*.json` **is the authoritative list** of outstanding violations.
- Batch 1 & 2 produced the majority of required fixes (heredoc usage, SQL/nonce issues, PHPECC `rand()`, prefixing).

## 3. Remediation Progress (as of this log)
- **Settings UI** (`bwwc-render-settings.php`):
  - Removed heredocs, added WordPress notices and nonces.
  - Escaped all dynamic values in both General & Advanced forms.
- **Settings Save Pipeline** (`bwwc-admin.php`):
  - Added `BWWC__sanitize_recursive()` to sanitize every incoming setting before saving/resetting.
  - Persistent-settings helper queries now use `$wpdb->prepare()`.
- **Electrum Address Management** (`bwwc-utils.php`, `bwwc-cron.php`):
  - Wrapped every dynamic SQL call with `$wpdb->prepare()` and sanitized metadata lookups.

## 4. Outstanding Work
1. Finish auditing the remaining `$wpdb` queries (other helpers/cron paths).
2. Update PHPECC utilities to use `wp_rand()` and drop `var_export()` debug output; prefix legacy globals.
3. Move text-domain loading into an `init` hook and ensure no `load_plugin_textdomain()` calls run too early.
4. Rerun the already-configured CLI batches to confirm the JSON reports go clean.

*Document created by Cascade autop-runner on {{DATE}}.*
