# TOOLS.md — SendBSV (Payments Backbone + Web POS)

> One-page toolkit for **SendBSV**: paymail domain on `sendbsv.com`, invoices, merchant web POS, and the Payment Confidence Engine. Focused on **standards-first** + “don’t reinvent wheels.”

READ THIS FIRST:  https://fast.brc.dev/llm-training-guide.txt

---

## 1) Standards & Building Blocks (align with ecosystem)

### Yours Wallet (wallet ↔ app interface)
- Hub: https://yours-wallet.gitbook.io/provider-api/

### Paymail / BSVAlias + BRC-28 (Payment Destinations)
Use paymail for `MerchantXYZ@sendbsv.com`, rotating destination scripts, and optional P2P tx submit.
- Hub: https://hub.bsvblockchain.org/

### BRC-100 (wallet ↔ app interface)
Optional enhancement mode: when a BRC-100 wallet exists, we can offer a “connect wallet” path without requiring it.
- Hub: https://hub.bsvblockchain.org/

### mAPI / miner signals (0-conf hardening)
Use miner/status signals as evidence sources in the Confidence Engine.
- TAAL mAPI: https://mapi.taal.com/swagger
- GorillaPool mAPI: https://mapi.gorillapool.io/swagger

### ARC (broadcast/status lifecycle)
Where available, use ARC-style transaction processing for stronger lifecycle/status.
- Hub: https://hub.bsvblockchain.org/

### SPV Wallet (evaluate as reference/blueprint)
Use as reference backend/blueprint or internal service only if it does not compromise non-custodial posture.
- Hub: https://hub.bsvblockchain.org/

---

## 2) Chain SDK (transactions, scripts, utilities)

### **@bsv/sdk**
Single SDK for keys, tx building, scripts, serialization.
- NPM: https://www.npmjs.com/package/@bsv/sdk

**Install**
```bash
npm i @bsv/sdk
```

---

## 3) Paymail Server (sendbsv.com)
Implement:
- `/.well-known/bsvalias` (capability discovery)
- Payment destination endpoint (returns outputs/scripts; include protocol-fee output)
- Optional: rawtx receive endpoint (P2P tx submit)

Suggested server stack:
- **Fastify** (recommended) or **Express**
- **zod** for request validation

**Install**
```bash
npm i fastify zod
# or
npm i express zod
```

---

## 4) Core Backend Services

### API framework
- **Fastify** + **@fastify/jwt** (or equivalent)
- **OpenAPI** generation optional

### Database
Pick one and stick to it:
- **Postgres** (recommended) + **Prisma** ORM

### Queue / background jobs
For provider polling, webhooks, FX refresh, cleanup:
- **BullMQ** (Redis)

### Realtime updates (POS status)
- **WebSocket** (ws) OR **SSE** (EventSource) for invoice status streams

**Install**
```bash
npm i fastify @fastify/jwt prisma @prisma/client
npm i bullmq ioredis
npm i ws
```

---

## 5) Payment Confidence Engine (evidence adapters)

Evidence adapters should be pluggable:
- Wallet callback adapter (when available)
- Observer adapter A (TAAL)
- Observer adapter B (GorillaPool)
- Optional mAPI/ARC adapters

Recommended structure:
- `EvidenceCollector` → emits `TxObservation`
- `DecisionEngine` → state machine for `PAID_FAST`, `PAID_VERIFIED`, `CONFIRMED`, exceptions

State machine helpers:
- **xstate** (optional)

**Install**
```bash
npm i xstate
```

---

## 6) FX / Pricing

### CoinGecko pricing
- Cache window: **5 minutes**
- If last-known FX **stale > 20 minutes**: warn merchant and let merchant decide

HTTP client:
- **undici** (Node fetch) or **axios**

**Install**
```bash
npm i undici
# or
npm i axios
```

---

## 7) Auth, Security, and Abuse Controls

### Auth
- JWT sessions for merchant UI
- Optional: passkeys later

### Rate limiting
- Fastify rate limit plugin or reverse-proxy rate limiting

### Webhooks integrity
- HMAC signatures for any inbound webhook endpoints

### Logging
- **pino** (Fastify native)

**Install**
```bash
npm i @fastify/rate-limit pino
```

---

## 8) Merchant Web POS (UI)

UI goals:
- Instant invoice creation
- QR + deeplinks
- Live status
- Bill-of-sale description
- Custom invoice numbers
- Transaction history + export (CSV/JSON)
- Lockout mode for staff

Recommended UI stack:
- **Next.js** (or Vite + React)
- **shadcn/ui** + **TailwindCSS**
- **react-hook-form** + **zod**
- **lucide-react**

**Install (common)**
```bash
npm i react-hook-form zod lucide-react
```

---

## 9) CSV / Export
- **papaparse** (CSV) or server-side CSV generation

**Install**
```bash
npm i papaparse
```

---

## 10) Env Vars (SendBSV defaults)
```bash
# Core
APP_ENV=prod
BASE_URL=https://sendbsv.com
BSV_NETWORK=main

# DB / Queue
DATABASE_URL=postgres://...
REDIS_URL=redis://...

# Auth
JWT_SECRET=...

# Paymail
PAYMAIL_DOMAIN=sendbsv.com
PAYMAIL_WELLKNOWN_PATH=/.well-known/bsvalias

# Protocol fee
APP_FEE_ADDRESS=1...   # later: APP_FEE_XPUB=xpub...

# FX
COINGECKO_BASE_URL=https://api.coingecko.com/api/v3
FX_CACHE_SECONDS=300
FX_STALE_WARN_SECONDS=1200

# Providers (MVP)
TAAL_MAPI_BASE=https://mapi.taal.com
GORILLAPOOL_MAPI_BASE=https://mapi.gorillapool.io
TAAL_API_KEY=...         # if needed
GORILLAPOOL_API_KEY=...  # if needed

# Realtime
POS_WS_URL=wss://sendbsv.com/ws
```

---

## 11) Quick Install Roll-up (typical)
```bash
npm i @bsv/sdk fastify zod prisma @prisma/client @fastify/jwt @fastify/rate-limit pino
npm i ws bullmq ioredis undici papaparse
# optional
npm i xstate
```

---

## 12) Minimal Wiring Order (for codingAI)
1) **Invoice API**: create/get/status-stream; enforce min 5,000 sats; FX cache + staleness warn.
2) **Paymail server** (`sendbsv.com`): `/.well-known/bsvalias` + destination endpoint returning **merchant + fee outputs**; rotate per invoice.
3) **Observer adapters**: TAAL + GorillaPool; evidence → `PAID_FAST` then `PAID_VERIFIED`.
4) **POS UI**: QR/deeplink + live status + history + export + lockout.
5) **Exception states**: verification delayed, conflict handling, partial/overpay.
6) **Manual refunds tooling** (merchant/admin UI + records).
7) Optional: **BRC-100 adapter mode** in UI when a wallet is available (never required).

---

## 13) Supply-Chain Hygiene (must-do)
- Pin versions + lockfile; avoid surprise updates.
- No analytics/ads SDKs in MVP.
- Keep secrets out of client builds.
- Add basic threat model notes in README.

